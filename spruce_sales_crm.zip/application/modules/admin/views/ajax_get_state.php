<?php foreach($state as $stt){ ?>
<option value="<?php echo $stt->id; ?>"><?php echo $stt->name; ?></option>
<?php }?>