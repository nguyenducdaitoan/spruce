<?php foreach($cities as $city){ ?>
<option value="<?php echo $city->id; ?>"><?php echo $city->name; ?></option>
<?php }?>