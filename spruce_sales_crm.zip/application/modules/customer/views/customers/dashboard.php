        <!-- BEGIN PAGE CONTENT -->
        <div class="page-content page-thin">
           <div class="row">
              <!--<h3 class="m-t-30 m-b-10"><strong>Counters</strong></h3> -->         
        	  <div class="row m-t-10">
            <div class="col-xlg-2 col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="panel">
                <div class="panel-content widget-info">
                  <div class="row">
                    <div class="left">
                      <i class="fa fa-users bg-green"></i>
                    </div>
                    <div class="right">
                      <p class="number countup" data-from="0" data-to="52000">0</p>
                      <p class="text">Users</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xlg-2 col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="panel">
                <div class="panel-content widget-info">
                  <div class="row">
                    <div class="left">
                      <i class="fa fa-cube bg-blue"></i>
                    </div>
                    <div class="right">
                      <p class="number countup" data-from="0" data-to="575" data-suffix="k">0</p>
                      <p class="text">Product</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xlg-2 col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="panel">
                <div class="panel-content widget-info">
                  <div class="row">
                    <div class="left">
                      <i class="fa fa-key bg-red"></i>
                    </div>
                    <div class="right">
                      <p class="number countup" data-from="0" data-to="463" data-suffix="k">0</p>
                      <p class="text">Leads</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
              
          </div>
          
          
          </div>
           
         
        </div>
        <!-- END PAGE CONTENT -->
      